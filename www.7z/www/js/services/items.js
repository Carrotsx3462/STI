angular.module('App').factory('Items', function (FURL, $firebaseArray, $firebaseObject, Utils) {
    var ref = new Firebase(FURL);
    return {
        AddOTP: function (user, otp) {
            var ItemRef = ref.child('OTP');
            ItemRef.child(user.num).set({
                Contact: user.num,
                Value: otp,
                Email: user.email,
                Name: user.name,
                
            })
        },
        AddScammer: function (user) {
            var ScammerRef = $firebaseArray(ref.child('Scammer'));
            ScammerRef.$add(user);
        },
        FindReview: function (reviewee) {
            var Reviewref = new Firebase("https://scamdefender.firebaseio.com/reviews/");
            var Reviewref2 = Reviewref.child(reviewee);
            var Review = $firebaseArray(Reviewref2);
            return Review;
        }
    }
});
angular.module('App').factory('Save', function (FURL, $firebaseArray, $firebaseObject, Utils) {
    var savedData = {};
    function set(data) {
        savedData = data;
    }
    function get() {
        return savedData;
    }

    return {
        set: set,
        get: get
    }
});
