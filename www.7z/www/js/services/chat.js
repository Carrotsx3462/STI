angular.module('App').factory('Chats', function ($firebase, $firebaseArray) {
    var ref = new Firebase("https://scamdefender.firebaseio.com/Chatroom/");
    var chats = $firebaseArray(ref);

    return {
        send: function (from, message) {
            //console.log("sending message from : " + from + " & message is " + message);
            if (from && message) {
                var chatMessage = {
                    from: from,
                    message: message,
                    createdAt: Firebase.ServerValue.TIMESTAMP
                };
                chats.$add(chatMessage).then(function (data) {
                    console.log("message added");
                });
            }
        },
        all: function () {
            return chats;
        }
    }
});