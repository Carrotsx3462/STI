'Use Strict';
angular.module('App', ['ionic','ngStorage', 'ngCordova','firebase','ngMessages'])
.config(function($stateProvider, $urlRouterProvider) {
    $stateProvider
    .state('login', {
      url: '/login',
      templateUrl: 'views/login/login.html',
      controller:'loginController'
    })
    .state('profile', {
        url: '/profile',
        templateUrl: 'views/profile/profile.html',
        controller: 'profileController'
    })
    .state('profile2', {
        url: '/profile2',
        templateUrl: 'views/profile2/profile2.html',
        controller: 'profile2Controller'
    })
    .state('reviews', {
        url: '/reviews',
        templateUrl: 'views/profile/reviews.html',
        controller: 'profileController'
    })
    .state('settings', {
        url: '/settings',
        templateUrl: 'views/settings/settings.html',
        controller: 'settingsController'
    })
    .state('chatroom', {
        url: '/chatroom',
        templateUrl: 'views/chatroom/chatroom.html',
        controller: 'chatroomController'
    })
    .state('reverseimg', {
        url: '/reverseimg',
        templateUrl: 'views/reverseimg/reverseimg.html',
        controller: 'reverseimgController'
    })
    .state('reverseimg2', {
        url: '/reverseimg2',
        templateUrl: 'views/reverseimg/reverseimg2.html',
        controller: 'reverseimgController'
    })
    .state('register2', {
        url: '/register2',
        templateUrl: 'views/register2/register2.html',
        controller: 'register2Controller'
    })
    .state('forgot', {
      url: '/forgot',
      templateUrl: 'views/forgot/forgot.html',
      controller:'forgotController'
    })
    .state('register', {
      url: '/register',
      templateUrl: 'views/register/register.html',
      controller:'registerController'
    })
    .state('home', {
      url: '/home',
      templateUrl: 'views/home/home.html',
      controller:'homeController'
    })
    .state('scans', {
        url: '/scans',
        templateUrl: 'views/scans/scans.html',
        controller: 'scanController'
    })
    .state('intermission', {
        url: '/intermission',
        templateUrl: 'views/home/intermission.html',
        controller: 'homeController'
    })
    ;
$urlRouterProvider.otherwise("/login");
})

// Changue this for your Firebase App URL.
.constant('FURL', 'https://scamdefender.firebaseio.com/')


.run(function($ionicPlatform) {
  $ionicPlatform.ready(function() {
    // Hide the accessory bar by default (remove this to show the accessory bar above the keyboard
    // for form inputs)
    if(window.cordova && window.cordova.plugins.Keyboard) {
      cordova.plugins.Keyboard.hideKeyboardAccessoryBar(true);
    }
    if(window.StatusBar) {
      StatusBar.styleDefault();
    }
  });
});
