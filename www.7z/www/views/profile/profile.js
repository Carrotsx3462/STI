angular.module('App').controller('profileController', function ($scope, $state, $cordovaOauth, $localStorage, $location, $http, $ionicPopup, $firebaseObject, Auth, FURL, Utils, Items) {
    var ref = new Firebase("https://scamdefender.firebaseio.com/profile/");
    $scope.email = $localStorage.email;
    $scope.id = $localStorage.userkey;
    $scope.username = $localStorage.username;
    $scope.Description = $localStorage.desc
    $scope.Gravatar = $localStorage.pic;
    $scope.contactnum = $localStorage.contactnum;
    $scope.address = $localStorage.address;

    var ref2 = new Firebase("https://scamdefender.firebasio.com/reviews/");
    
    Utils.show();
    Utils.hide();
    var Review = new Firebase("https://scamdefender.firebaseio.com/reviews/");
    var Review2 = Review.child($localStorage.username);
    $scope.Reviews = Items.FindReview($localStorage.username);


    $scope.ViewReviews = function () {
        $location.path('/reviews');
    }
    $scope.EditProfile = function () {
        $location.path('/profile2');
    }

});