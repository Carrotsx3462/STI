angular.module('App').controller('profile2Controller', function ($scope, $state, $cordovaOauth, $localStorage, $location, $http, $ionicPopup, $firebaseObject, $firebaseArray, Auth, FURL, Utils) {
    var ref = new Firebase("https://scamdefender.firebaseio.com/profile/");
    $scope.Zing = function (update) {
        var email = $localStorage.email;
        var id = $localStorage.userkey;
        var username = $localStorage.username;
        var Address = update.Address;
        var Description = update.Description;
        var gravatar = $localStorage.pic;
        var register = $localStorage.date;
        var id2 = $localStorage.eid;
        var num = $localStorage.contactnum;
        $localStorage.desc = Description;
        $localStorage.address = Address;
        var profileref = ref.child(id);
        profileref.set({
            email: email,
            id: id2,
            MobileNumber: num,
            username: username,
            address: Address,
            description: Description,
            gravatar: gravatar,
            registered_in: register
        })
        $location.path('/profile');
    }
});