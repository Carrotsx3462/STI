'Use Strict';
angular.module('App').controller('registerController', function ($scope, Items, Save, $state, $cordovaOauth, $localStorage, $location, $http, $ionicPopup, $firebaseObject, Auth, FURL, Utils) {
    function makeid() { //this function is for generating random numbers
        var text = "";
        var possible = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
        for (var i = 0; i < 5; i++)
            text += possible.charAt(Math.floor(Math.random() * possible.length));
        return text;
    }
    $scope.register = function (user) {
        var otp = makeid(5);
        var dstno = 6500000000 + user.num;
        var email = user.email;
        var inbetween = "&dstno=";
        var defaultsms = "http://www.isms.com.my/isms_send.php?un=WinetasterSG&pwd=WineTaster2016!&type=1&senderid=ScmDefender&msg=OneTimePassword:";
        Items.AddOTP(user, otp);
        Save.set(user);
        $location.path('/register2');
        $http.get(defaultsms + otp + inbetween + dstno);
    }
});