angular.module('App').controller('chatroomController', function ($scope, $state, $cordovaOauth, $localStorage, $location, $http, $ionicPopup, $firebaseObject, Auth, FURL, Utils, Chats) {
    $scope.username = $localStorage.username;
    var Displayname = $localStorage.username;
    $scope.chats = Chats.all();
    $scope.id = $localStorage.userkey;
    $scope.IM = {
        textMessage: ""
    };

    $scope.sendMessage = function (msg) {
        console.log(msg);
        Chats.send(Displayname, msg);
        $scope.IM.textMessage = "";
    }

});