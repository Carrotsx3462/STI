'Use Strict';
angular.module('App').controller('scanController', function ($scope, $firebaseArray, $firebase, FURL, Utils, Items) {
    $scope.AddStuff = function (stuff) {
        if (angular.isDefined(stuff)) {
            Utils.show();
            $scope.Jass2 = stuff.email;
            $scope.Jass3 = "No results found";
            var ref2 = new Firebase("https://scamdefender.firebaseio.com/Scammer");
            ref2.orderByChild("email").equalTo(stuff.email).on("child_added", function (snapshot) {
                Utils.hide();
                var Jax = snapshot.key();
                $scope.Jass = Jax;
                console.log(snapshot.key());
                if (angular.isDefined(Jax)) {
                    $scope.Jass3 = "Fraudster Alert!!";
                }
            })
            Utils.hide();
        }
    }
});