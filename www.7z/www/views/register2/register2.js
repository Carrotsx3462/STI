'Use Strict';
angular.module('App').controller('register2Controller', function ($scope, Items, Save, $state, $cordovaOauth, $localStorage, $location, $http, $ionicPopup, $firebaseObject, Auth, FURL, Utils) {
    var user = Save.get();
    $scope.please = user.num;

    $scope.Derp = function (otp) {
        var x = otp;
        $scope.buttonpressed = "Yes";
        $scope.buttonvalue = x;
        var ref = new Firebase("https://scamdefender.firebaseio.com/OTP/");
        ref.once("value", function (snapshot) {
            var ContactSnapshot = snapshot.child(user.num).child("Value");
            var TheOTP = ContactSnapshot.val();
            $scope.TheOTP = TheOTP;
            if (x == TheOTP) {
                if (angular.isDefined(user)) {
                    Utils.show();
                    Auth.register(user).then(function () {
                        Utils.hide();
                        console.log("Registration: " + JSON.stringify(user));
                        Utils.alertshow("Successfully", "The User was Successfully Created.");
                        $location.path('/login');
                    }, function (err) {
                        Utils.hide();
                        Utils.errMessage(err);
                    });
                }
            } else {
                $scope.Error = "Wrong OTP";
            }
        });
    }
});
