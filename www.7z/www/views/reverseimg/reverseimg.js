angular.module('App').controller('reverseimgController', function ($scope,$location, $firebaseArray, $firebase, FURL, Utils, Items) {
    $scope.UploadImg = function () {
        $location.path('/reverseimg2');
    }

});